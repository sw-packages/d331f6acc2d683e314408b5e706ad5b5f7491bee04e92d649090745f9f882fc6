PRAGMA page_size = 4096;
PRAGMA foreign_keys = 1;

BEGIN;
